package com.nxp.nfc_demo.flutter


import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.util.Log
import android.view.View
import com.nxp.nfc_demo.activities.AuthActivity
import com.nxp.nfc_demo.activities.MainActivity
import com.nxp.nfc_demo.activities.VersionInfoActivity
//import com.nxp.nfc_demo.activities.RegisterSessionActivity as ANROID_THEAD
import com.nxp.nfc_demo.exceptions.CommandNotSupportedException

import com.nxp.nfc_demo.reader.Ntag_I2C_Demo
import com.nxp.nfc_demo.reader.Ntag_I2C_Registers
import com.nxp.ntagi2cdemo.R;

import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry
import io.flutter.plugin.common.PluginRegistry.Registrar
import io.flutter.app.FlutterActivity
import io.flutter.view.FlutterView

const val CHANNEL_NAME:String = "$BASE_NAME.RegisterSession"


class RegisterSessionChannel(private val registrar: Registrar,
                             private val internal_thread: RegisterSessionActivity) : MethodCallHandler, AndroidFlutterMediator()
{
    companion object {
        @JvmStatic
        val CHANNEL:String = CHANNEL_NAME;

        @JvmStatic
        fun registerWith(registrar: PluginRegistry.Registrar): Unit {
            val channel = MethodChannel(registrar.messenger(), CHANNEL_NAME)
            val instance = RegisterSessionChannel(registrar, RegisterSessionActivity());
            channel.setMethodCallHandler(instance)
        }
    }

    override fun intentMatched(intent:Intent): Boolean {
        //todo:
        debug("onIntent", intent)
        return true
    }

    override fun resultMatched(requestCode: Int, data: Intent): Boolean{
        //todo:
        debug("onResult", data)
        return true
    }

    init {
        registrar.addNewIntentListener (PluginRegistry.NewIntentListener {
            onNewIntent(it);
        })
        registrar.addActivityResultListener(PluginRegistry.ActivityResultListener {
            request, result, intent -> onActivityResult(request, result, intent)
        })
    }

    override fun onMethodCall(call: MethodCall, result: Result): Unit {
        Log.v("Ntag", "method: ${call.method}");
        when(call.method){
            "$CHANNEL_NAME.isConnected" -> {
                result.success("c");
            }
        }
    }
}

class RegisterSessionActivity(): FakeActivity {
    private var pendingIntent: PendingIntent? = null
    private var mAdapter: NfcAdapter? = null
    private var activity: Activity? = null
    var demo: Ntag_I2C_Demo? = null


    override fun onCreate(savedInstanceState: Bundle?, intent: Intent, activity: Activity) {
        this.activity = activity
        /*IC_Manufacturer_text = R.id.IC_Product_text.toString()
        Mem_size_text = R.id.Mem_size_text.toString()
        FD_OFF_text = R.id.FD_OFF_text.toString()
        FD_ON_text = R.id.FD_ON_text.toString()
        LAST_NDEF_Page_text = R.id.LAST_NDEF_Page_text.toString()
        SRAM_Mirror_Reg_text = R.id.SRAM_Mirror_Reg_text.toString()
        WD_LS_Reg_text = R.id.WD_LS_Reg_text.toString()
        WD_MS_Reg_text = R.id.WD_MS_Reg_text.toString()

        I2C_RST_ON_OFF_checkbox = R.id.I2C_RST_ON_OFF_checkbox.toString()
        NDEF_DATA_READ_checkbox = R.id.NDEF_DATA_READ_checkbox.toString()
        RF_FIELD_PRESENT_checkbox = R.id.RF_FIELD_PRESENT_checkbox .toString()
        PT_ON_OFF_checkbox = R.id.PT_ON_OFF_checkbox .toString()
        I2C_LOCKED_checkbox = R.id.I2C_LOCKED_checkbox .toString()
        RF_LOCKED_checkbox = R.id.RF_LOCKED_checkbox .toString()
        SRAM_I2C_ready_checkbox = R.id.SRAM_I2C_ready_checkbox .toString()
        SRAM_RF_ready_checkbox = R.id.SRAM_RF_ready_checkbox .toString()
        PT_DIR_checkbox = R.id.PT_DIR_checkbox .toString()
        SRAM_Miror_checkbox = R.id.SRAM_Miror_checkbox .toString()
        CI2C_CLOCK_STR_checkbox = R.id.I2C_CLOCK_STR_checkbox .toString()*/

        // Capture intent to check whether the operation should be automatically launch or not
        val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
        if (tag != null && Ntag_I2C_Demo.isTagPresent(tag)) {
            startDemo(tag, false)
        }
        // Add Foreground dispatcher
        mAdapter = NfcAdapter.getDefaultAdapter(activity)
        pendingIntent = PendingIntent.getActivity(activity, 0,
                Intent(activity, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0)
    }

    override fun onPause() {
        if (mAdapter != null)
            mAdapter!!.disableForegroundDispatch(activity)
    }

    override fun onResume() {
        if (mAdapter != null) {
            mAdapter!!.enableForegroundDispatch(activity, pendingIntent, null, null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        // Check which request we're responding to
        // Make sure the request was successful
        if (requestCode == MainActivity.AUTH_REQUEST
                && resultCode == Activity.RESULT_OK
                && demo != null
                && demo!!.isReady) {
            // Launch the thread
            try {
                demo!!.readSessionRegisters()
            } catch (e: CommandNotSupportedException) {
                showAlert("This NFC device does not support the NFC Forum " + "commands needed to access the session register")
                return
            }
            // Make visible the registers scrollview
            UIshowLayout()
        }
    }

    override fun onNewIntent(nfcIntent: Intent) {
        // Set the initial auth parameters
        MainActivity.setAuthStatus(AuthActivity.AuthStatus.Disabled.value)
        MainActivity.setPassword(null)

        // Store the intent information
        MainActivity.setNfcIntent(nfcIntent)
        val tag = nfcIntent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
        startDemo(tag, true)
    }

    private fun startDemo(tag: Tag, getAuthStatus: Boolean) {
        demo = Ntag_I2C_Demo(tag, activity, MainActivity.getPassword(), MainActivity.getAuthStatus())
        if (!demo!!.isReady) {
            return
        }

        // Retrieve the Auth Status
        if (getAuthStatus) {
            MainActivity.setAuthStatus(demo!!.ObtainAuthStatus())
        }

        // Demo is available when the tag is not protected or the memory is only write-protected
        if (MainActivity.getAuthStatus() == AuthActivity.AuthStatus.Disabled.value
                || MainActivity.getAuthStatus() == AuthActivity.AuthStatus.Unprotected.value
                || MainActivity.getAuthStatus() == AuthActivity.AuthStatus.Authenticated.value
                || MainActivity.getAuthStatus() == AuthActivity.AuthStatus.Protected_W.value
                || MainActivity.getAuthStatus() == AuthActivity.AuthStatus.Protected_W_SRAM.value) {
            try {
                demo!!.readSessionRegisters()
            } catch (e: CommandNotSupportedException) {
                showAlert("This NFC device does not support the NFC Forum commands needed to access the session register")
                return
            }

            // Make visible the registers scrollview
            UIshowLayout()
        } else {
            showAuthDialog()
        }
    }
    fun showAlert(msg:String){
        UIshowAlert(msg);
    }
    fun showAuthDialog() {
        UIshowAuthDialog();
    }

    fun showAboutDialog() {
        UIshowAboutDialog();
    }

    companion object {
        private var IC_Manufacturer_text: String? = null
        private var Mem_size_text: String? = null
        private var FD_OFF_text: String? = null
        private var FD_ON_text: String? = null
        private var LAST_NDEF_Page_text: String? = null
        private var SRAM_Mirror_Reg_text: String? = null
        private var WD_LS_Reg_text: String? = null
        private var WD_MS_Reg_text: String? = null

        private var I2C_RST_ON_OFF_checkbox: String? = null
        private var NDEF_DATA_READ_checkbox: String? = null
        private var RF_FIELD_PRESENT_checkbox: String? = null
        private var PT_ON_OFF_checkbox: String? = null
        private var I2C_LOCKED_checkbox: String? = null
        private var RF_LOCKED_checkbox: String? = null
        private var SRAM_I2C_ready_checkbox: String? = null
        private var SRAM_RF_ready_checkbox: String? = null
        private var PT_DIR_checkbox: String? = null
        private var SRAM_Miror_checkbox: String? = null
        private var CI2C_CLOCK_STR_checkbox: String? = null

        fun SetAnswer(answer: Ntag_I2C_Registers, cont: Context) {
            IC_Manufacturer_text = answer.Manufacture
            Mem_size_text = answer.Mem_size.toString() + " Bytes"

            if (answer.I2C_RST_ON_OFF) {
                I2C_RST_ON_OFF_checkbox = true.toString()
            } else {
                I2C_RST_ON_OFF_checkbox = false.toString()
            }

            if (answer.FD_OFF == "00b") {
                FD_OFF_text = R.string.FD_OFF00.toString()
            } else if (answer.FD_OFF == "01b") {
                FD_OFF_text=R.string.FD_OFF01.toString()
            } else if (answer.FD_OFF == "10b") {
                FD_OFF_text=R.string.FD_OFF10.toString()
            } else
                FD_OFF_text=R.string.FD_OFF11.toString()

            if (answer.FD_ON == "00b") {
                FD_ON_text=R.string.FD_ON00.toString()
            } else if (answer.FD_ON == "01b") {
                FD_ON_text=R.string.FD_ON01.toString()
            } else if (answer.FD_ON == "10b") {
                FD_ON_text=R.string.FD_ON10.toString()
            } else
                FD_ON_text=R.string.FD_ON11.toString()

            LAST_NDEF_Page_text = answer.LAST_NDEF_PAGE.toString()

            if (answer.NDEF_DATA_READ) {
                NDEF_DATA_READ_checkbox = true.toString()
            } else {
                NDEF_DATA_READ_checkbox = false.toString()
            }

            if (answer.RF_FIELD_PRESENT) {
                RF_FIELD_PRESENT_checkbox = true.toString()
            } else {
                RF_FIELD_PRESENT_checkbox = false.toString()
            }

            if (answer.PTHRU_ON_OFF) {
                PT_ON_OFF_checkbox = true.toString()
            } else {
                PT_ON_OFF_checkbox = false.toString()
            }

            if (answer.I2C_LOCKED) {
                I2C_LOCKED_checkbox = true.toString()
            } else {
                I2C_LOCKED_checkbox = false.toString()
            }

            if (answer.RF_LOCKED) {
                RF_LOCKED_checkbox = true.toString()
            } else {
                RF_LOCKED_checkbox = false.toString()
            }

            if (answer.SRAM_I2C_READY) {
                SRAM_I2C_ready_checkbox = true.toString()
            } else {
                SRAM_I2C_ready_checkbox = false.toString()
            }

            if (answer.SRAM_RF_READY) {
                SRAM_RF_ready_checkbox = true.toString()
            } else {
                SRAM_RF_ready_checkbox = false.toString()
            }

            if (answer.PTHRU_DIR) {
                PT_DIR_checkbox = true.toString()
            } else {
                PT_DIR_checkbox = false.toString()
            }

            if (answer.SRAM_MIRROR_ON_OFF) {
                SRAM_Miror_checkbox = true.toString()
            } else {
                SRAM_Miror_checkbox = false.toString()
            }
            SRAM_Mirror_Reg_text = answer.SM_Reg.toString()
            WD_LS_Reg_text = answer.WD_LS_Reg.toString()
            WD_MS_Reg_text = answer.WD_MS_Reg.toString()

            if (answer.I2C_CLOCK_STR) {
                CI2C_CLOCK_STR_checkbox = true.toString()
            } else {
                CI2C_CLOCK_STR_checkbox = false.toString()
            }
        }
    }

    fun UIshowAuthDialog() {
        //fixme: start AuthActivity
        var intent: Intent = Intent(activity, AuthActivity::class.java)
        intent.putExtras(MainActivity.getNfcIntent())
        //startActivityForResult(intent, MainActivity.AUTH_REQUEST)
    }

    fun UIshowAboutDialog() {
        //fixme: start versionInfoActivity
        var intent: Intent = Intent(activity, VersionInfoActivity::class.java)
        //startActivity(intent)
    }
    fun UIshowAlert(msg:String){
        /*
        //note: blocked
        AlertDialog.Builder(activity)
                .setMessage(
                        "This NFC device does not support the NFC Forum commands needed to access the session register")
                .setTitle("Command not supported")
                .setPositiveButton("OK"
                ) { dialog, which -> }.show()*/
        //todo:
    }
    fun UIshowLayout(){
        /*
            //note: blocked
            layout_read!!.visibility = View.GONE
            scroll_regs!!.visibility = View.VISIBLE*/
        //todo:
        return;
    }
    fun UIsetAnswer (){
        //todo:
        var ret:Map<String, Any?> = mapOf(
                "FD_OFF_text" to FD_OFF_text,
                "FD_ON_text" to FD_ON_text,
                "IC_Manufacturer_text" to IC_Manufacturer_text,
                "LAST_NDEF_Page_text" to LAST_NDEF_Page_text,
                "Mem_size_text" to Mem_size_text,
                "Mem_size_text" to Mem_size_text,
                "SRAM_Mirror_Reg_text" to SRAM_Mirror_Reg_text,
                "WD_LS_Reg_text" to WD_LS_Reg_text,
                "WD_MS_Reg_text" to WD_MS_Reg_text,

                "CI2C_CLOCK_STR_checkbox" to CI2C_CLOCK_STR_checkbox,
                "I2C_LOCKED_checkbox" to I2C_LOCKED_checkbox,
                "I2C_RST_ON_OFF_checkbox" to I2C_RST_ON_OFF_checkbox,
                "NDEF_DATA_READ_checkbox" to NDEF_DATA_READ_checkbox,
                "PT_DIR_checkbox" to PT_DIR_checkbox,
                "PT_ON_OFF_checkbox" to PT_ON_OFF_checkbox,
                "RF_FIELD_PRESENT_checkbox" to RF_FIELD_PRESENT_checkbox,
                "RF_LOCKED_checkbox" to RF_LOCKED_checkbox,
                "SRAM_I2C_ready_checkbox" to SRAM_I2C_ready_checkbox,
                "SRAM_Miror_checkbox" to SRAM_Miror_checkbox,
                "SRAM_RF_ready_checkbox" to SRAM_RF_ready_checkbox
        )
    }
}
