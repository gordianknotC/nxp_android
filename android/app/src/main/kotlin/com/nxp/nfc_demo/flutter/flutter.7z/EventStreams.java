package com.nxp.nfc_demo.flutter;

import android.content.Context;
import com.nxp.nfc_demo.reader.Ntag_I2C_Registers;


public class EventStreams {
   public static void SetAnswer(Ntag_I2C_Registers answer, Context cont) {

   }
}
