package com.nxp.nfc_demo.flutter

import android.app.Activity
import android.content.Intent
import android.os.Bundle

interface FakeActivity{
    fun onCreate(savedInstanceState: Bundle?, intent: Intent, activity: Activity)
    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent)
    fun onNewIntent(intent: Intent)
    fun onPause()
    fun onResume()
}