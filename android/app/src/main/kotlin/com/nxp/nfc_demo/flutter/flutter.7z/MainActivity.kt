/*
package com.nxp.nfc_demo.flutter


import java.util.Locale

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager.NameNotFoundException
import android.content.res.Configuration
import android.net.Uri
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.os.Vibrator
import android.support.v4.app.FragmentActivity
import android.support.v4.view.ViewPager
import android.view.Menu
import android.view.MenuItem
import android.widget.TabHost
import android.widget.TabHost.OnTabChangeListener
import android.widget.Toast

import com.nxp.nfc_demo.activities.AuthActivity.AuthStatus
import com.nxp.nfc_demo.activities.VersionInfoActivity
import com.nxp.nfc_demo.adapters.TabsAdapter
import com.nxp.nfc_demo.fragments.ConfigFragment
import com.nxp.nfc_demo.fragments.LedFragment
import com.nxp.nfc_demo.fragments.NdefFragment
import com.nxp.nfc_demo.fragments.SpeedTestFragment
import com.nxp.nfc_demo.reader.Ntag_I2C_Demo
import com.nxp.ntagi2cdemo.R

import io.flutter.app.FlutterActivity

class MainActivity (): FlutterActivity() {
    private var mTabHost: TabHost? = null
    private var mViewPager: ViewPager? = null
    private var mTabsAdapter: TabsAdapter? = null
    private var mPendingIntent: PendingIntent? = null
    private var mAdapter: NfcAdapter? = null


    // Reference to menu item for icon changing
    private var mAuthMenuItem: MenuItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Application package name to be used by the AAR record
        PACKAGE_NAME = applicationContext.packageName
        val languageToLoad = "en"
        val locale = Locale(languageToLoad)
        Locale.setDefault(locale)
        val config = Configuration()
        config.locale = locale
        baseContext.resources.updateConfiguration(config,
                baseContext.resources.displayMetrics)
        setContentView(R.layout.activity_main)
        mTabHost = findViewById<View>(android.R.id.tabhost) as TabHost
        mTabHost!!.setup()
        mViewPager = findViewById(R.id.pager) as ViewPager
        mTabsAdapter = TabsAdapter(this, mTabHost, mViewPager)
        mTabsAdapter!!.addTab(
                mTabHost!!.newTabSpec("leds").setIndicator(
                        getString(R.string.leds)), LedFragment::class.java, null)
        mTabsAdapter!!.addTab(
                mTabHost!!.newTabSpec("ndef").setIndicator(
                        getString(R.string.ndefs)), NdefFragment::class.java, null)
        mTabsAdapter!!.addTab(
                mTabHost!!.newTabSpec("ntag_rf").setIndicator(
                        getString(R.string.ntag_rf_text)),
                SpeedTestFragment::class.java, null)
        mTabsAdapter!!.addTab(
                mTabHost!!.newTabSpec("config").setIndicator(
                        getString(R.string.settings)), ConfigFragment::class.java, null)

        // set current Tag to the Speedtest, so it loads the values
        if (savedInstanceState != null) {
            mTabHost!!.setCurrentTabByTag(savedInstanceState!!.getString("tab"))
        }
        // Get App version
        appVersion = ""
        try {
            val pInfo = packageManager.getPackageInfo(
                    packageName, 0)
            appVersion = pInfo.versionName
        } catch (e: NameNotFoundException) {
            e.printStackTrace()
        }

        // Board firmware version
        boardFirmwareVersion = "Unknown"

        // Notifier to be used for the demo changing
        mTabHost!!.setOnTabChangedListener { tabId ->
            if (demo!!.isReady) {
                demo!!.finishAllTasks()
                if (tabId.equals("leds", ignoreCase = true) && demo!!.isConnected) {
                    launchDemo(tabId)
                }
            }
            mTabsAdapter!!.onTabChanged(tabId)
        }
        // When we open the application by default we set the status to disabled (we don't know the product yet)
        authStatus = AuthStatus.Disabled.value

        // Initialize the demo in order to handle tab change events
        demo = Ntag_I2C_Demo(null, this, null, 0)
        mAdapter = NfcAdapter.getDefaultAdapter(this)
        setNfcForeground()
        checkNFC()
    }

    @SuppressLint("InlinedApi")
    private fun checkNFC() {
        if (mAdapter != null) {
            if (!mAdapter!!.isEnabled) {
                AlertDialog.Builder(this)
                        .setTitle("NFC not enabled")
                        .setMessage("Go to Settings?")
                        .setPositiveButton("Yes",
                                object : DialogInterface.OnClickListener {
                                    override fun onClick(dialog: DialogInterface,
                                                         which: Int) {
                                        if (android.os.Build.VERSION.SDK_INT >= 16) {
                                            startActivity(Intent(android.provider.Settings.ACTION_NFC_SETTINGS))
                                        } else {
                                            startActivity(Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS))
                                        }
                                    }
                                })
                        .setNegativeButton("No",
                                object : DialogInterface.OnClickListener {
                                    override fun onClick(dialog: DialogInterface,
                                                         which: Int) {
                                        System.exit(0)
                                    }
                                }).show()
            }
        } else {
            AlertDialog.Builder(this)
                    .setTitle("No NFC available. App is going to be closed.")
                    .setNeutralButton("Ok",
                            object : DialogInterface.OnClickListener {
                                override fun onClick(dialog: DialogInterface,
                                                     which: Int) {
                                    System.exit(0)
                                }
                            }).show()
        }
    }

    public override fun onPause() {
        super.onPause()
        if (mAdapter != null) {
            mAdapter!!.disableForegroundDispatch(this)
        }

        if (demo!!.isReady) {
            demo!!.finishAllTasks()
        }
    }

    public override fun onResume() {
        super.onResume()

        // Update the Auth Status Icon
        updateAuthIcon(authStatus)

        if (mAdapter != null) {
            mAdapter!!.enableForegroundDispatch(this, mPendingIntent, null, null)
        }
    }

    public override fun onDestroy() {
        super.onDestroy()
        authStatus = 0
        password = null
        nfcIntent = null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        // Check which request we're responding to
        // Make sure the request was successful
        if ((requestCode == AUTH_REQUEST
                        && resultCode == Activity.RESULT_OK
                        && demo != null
                        && demo!!.isReady)) {
            val currTab = mTabHost!!.currentTabTag
            launchDemo(currTab)
        }
    }

    override fun onNewIntent(nfc_intent: Intent) {
        super.onNewIntent(nfc_intent)
        // Set the pattern for vibration
        val pattern = longArrayOf(0, 100)

        // Set the initial auth parameters
        authStatus = AuthStatus.Disabled.value
        password = null

        // Vibrate on new Intent
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibrator!!.vibrate(pattern, -1)
        doProcess(nfc_intent)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)

        // Get the reference to the menu item
        mAuthMenuItem = menu.findItem(R.id.action_auth)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle presses on the action bar items
        when (item.itemId) {
            R.id.action_auth -> {
                showAuthDialog()
                return true
            }
            R.id.action_flash -> {
                showFlashDialog()
                return true
            }
            R.id.action_about -> {
                showAboutDialog()
                return true
            }
            R.id.action_feedback -> {
                sendFeedback()
                return true
            }
            R.id.action_help -> {
                showHlepDialog()
                return true
            }
            R.id.action_debug -> {
                showDebugDialog()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    fun doProcess(nfc_intent: Intent) {
        nfcIntent = nfc_intent
        val tag = nfc_intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
        demo = Ntag_I2C_Demo(tag, this, password, authStatus)
        if (demo!!.isReady) {
            // Retrieve Auth Status before doing any operation
            authStatus = obtainAuthStatus()
            val currTab = mTabHost!!.currentTabTag
            launchDemo(currTab)
        }
    }

    private fun launchDemo(currTab: String?) {
        if (authStatus == AuthStatus.Authenticated.value) {
            demo!!.Auth(password, AuthStatus.Protected_RW.value)
        }

        // ===========================================================================
        // LED Test
        // ===========================================================================
        if (currTab!!.equals("leds", ignoreCase = true)) {
            // This demo is available even if the product is protected
            // as long as the SRAM is unprotected
            if ((authStatus == AuthStatus.Disabled.value
                            || authStatus == AuthStatus.Unprotected.value
                            || authStatus == AuthStatus.Authenticated.value
                            || authStatus == AuthStatus.Protected_W.value
                            || authStatus == AuthStatus.Protected_RW.value)) {
                try {
                    // if (LedFragment.getChosen()) {
                    demo!!.LED()
                } catch (e: Exception) {
                    e.printStackTrace()
                    LedFragment.setAnswer(getString(R.string.Tag_lost))
                }

            } else {
                Toast.makeText(applicationContext, "NTAG I2C Plus memory is protected",
                        Toast.LENGTH_LONG).show()
                showAuthDialog()
            }
        }
        // ===========================================================================
        // NDEF Demo
        // ===========================================================================
        if (currTab!!.equals("ndef", ignoreCase = true)) {
            // This demo is only available when the tag is not protected
            if ((authStatus == AuthStatus.Disabled.value
                            || authStatus == AuthStatus.Unprotected.value
                            || authStatus == AuthStatus.Authenticated.value)) {
                NdefFragment.setAnswer("Tag detected")
                try {
                    demo!!.NDEF()
                } catch (e: Exception) {
                    // NdefFragment.setAnswer(getString(R.string.Tag_lost));
                }

            } else {
                Toast.makeText(applicationContext, "NTAG I2C Plus memory is protected",
                        Toast.LENGTH_LONG).show()
                showAuthDialog()
            }
        }
        // ===========================================================================
        // Config
        // ===========================================================================
        if (currTab!!.equals("config", ignoreCase = true)) {
        }
        // ===========================================================================
        // Speedtest
        // ===========================================================================
        if (currTab!!.equals("ntag_rf", ignoreCase = true)) {
            try {
                // SRAM Test
                if ((SpeedTestFragment.isSRamEnabled() == true)) {
                    // This demo is available even if the product is protected
                    // as long as the SRAM is unprotected
                    if ((authStatus == AuthStatus.Disabled.value
                                    || authStatus == AuthStatus.Unprotected.value
                                    || authStatus == AuthStatus.Authenticated.value
                                    || authStatus == AuthStatus.Protected_W.value
                                    || authStatus == AuthStatus.Protected_RW.value)) {
                        demo!!.SRAMSpeedtest()
                    } else {
                        Toast.makeText(applicationContext, "NTAG I2C Plus memory is protected",
                                Toast.LENGTH_LONG).show()
                        showAuthDialog()
                    }
                }
                // EEPROM Test
                if ((SpeedTestFragment.isSRamEnabled() == false)) {
                    // This demo is only available when the tag is not protected
                    if ((authStatus == AuthStatus.Disabled.value
                                    || authStatus == AuthStatus.Unprotected.value
                                    || authStatus == AuthStatus.Authenticated.value)) {
                        demo!!.EEPROMSpeedtest()
                    } else {
                        Toast.makeText(applicationContext, "NTAG I2C Plus memory is protected",
                                Toast.LENGTH_LONG).show()
                        showAuthDialog()
                    }
                } // end if eeprom test
            } catch (e: Exception) {
                SpeedTestFragment.setAnswer(getString(R.string.Tag_lost))
                e.printStackTrace()
            }

        }
    }

    private fun obtainAuthStatus(): Int {
        authStatus = demo!!.ObtainAuthStatus()

        // Update the Auth Status Icon
        updateAuthIcon(authStatus)
        return authStatus
    }

    fun sendFeedback() {
        val intent = Intent(Intent.ACTION_SENDTO)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_SUBJECT,
                this.getString(R.string.email_titel_feedback))
        intent.putExtra(Intent.EXTRA_TEXT, ("Android Version: "
                + android.os.Build.VERSION.RELEASE + "\nManufacurer: "
                + android.os.Build.MANUFACTURER + "\nModel: "
                + android.os.Build.MODEL + "\nBrand: " + android.os.Build.BRAND
                + "\nDisplay: " + android.os.Build.DISPLAY + "\nProduct: "
                + android.os.Build.PRODUCT + "\nIncremental: "
                + android.os.Build.VERSION.INCREMENTAL))
        intent.data = Uri.parse(this.getString(R.string.support_email))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        this.startActivity(intent)
    }

    fun showHlepDialog() {
        var intent: Intent? = null
        intent = Intent(this, HelpActivity::class.java)
        startActivity(intent)
    }

    fun showDebugDialog() {
        var intent: Intent? = null
        intent = Intent(this, DebugActivity::class.java)
        startActivity(intent)
    }

    fun showAboutDialog() {
        var intent: Intent? = null
        intent = Intent(this, VersionInfoActivity::class.java)
        if (MainActivity.nfcIntent != null)
            intent!!.putExtras(MainActivity.nfcIntent!!)

        startActivity(intent)
    }

    fun showFlashDialog() {
        var intent: Intent? = null
        intent = Intent(this, FlashMemoryActivity::class.java)
        startActivity(intent)
    }

    fun showAuthDialog() {
        if (authStatus != AuthStatus.Disabled.value) {
            var intent: Intent? = null
            intent = Intent(this, AuthActivity::class.java)
            intent!!.putExtras(MainActivity.nfcIntent!!)
            startActivityForResult(intent, AUTH_REQUEST)
        } else {
            Toast.makeText(applicationContext, ("You need to tap a NTAG I2C " + "Plus product to access authentication features"),
                    Toast.LENGTH_LONG).show()
        }
    }

    fun setNfcForeground() {
        // Create a generic PendingIntent that will be delivered to this
        // activity. The NFC stack will fill
        // in the intent with the details of the discovered tag before
        // delivering it to this activity.
        mPendingIntent = PendingIntent.getActivity(this, 0, Intent(
                applicationContext, javaClass)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0)
    }

    */
/**
     * Set the Icon that informs the user about the protection status.
     *//*

    fun updateAuthIcon(status: Int) {
        if (mAuthMenuItem != null) {
            if (status == AuthStatus.Disabled.value) {
                mAuthMenuItem!!.icon = resources.getDrawable(R.drawable.disabled)
            } else if (status == AuthStatus.Unprotected.value) {
                mAuthMenuItem!!.icon = resources.getDrawable(R.drawable.unlock)
            } else if (status == AuthStatus.Authenticated.value) {
                mAuthMenuItem!!.icon = resources.getDrawable(R.drawable.authenticated)
            } else if ((status == AuthStatus.Protected_RW.value
                            || status == AuthStatus.Protected_W.value
                            || status == AuthStatus.Protected_RW_SRAM.value
                            || status == AuthStatus.Protected_W_SRAM.value)) {
                mAuthMenuItem!!.icon = resources.getDrawable(R.drawable.lock)
            }
        }
    }

    companion object {
        val EXTRA_MESSAGE = "com.nxp.nfc_demo.MESSAGE"
        val AUTH_REQUEST = 0
        var demo: Ntag_I2C_Demo? = null
        var PACKAGE_NAME: String

        // Android app Version
        private var appVersion = ""

        // Board firmware Version
        private var boardFirmwareVersion = ""

        var nfcIntent: Intent? = null

        // Current authentication state
        // ===========================================================================
        // NTAG I2C Plus getters and setters
        // ===========================================================================
        var authStatus: Int = 0

        // Current used password
        var password: ByteArray? = null

        fun getmIntent(): Intent? {
            return nfcIntent
        }

        fun setBoardFirmwareVersion(boardFirmwareVersion: String) {
            MainActivity.boardFirmwareVersion = boardFirmwareVersion
        }

        */
/**
         * NDEF Demo execution is launched from its fragmend.
         *//*

        fun launchNdefDemo(auth: Int, pwd: ByteArray) {
            if (demo!!.isReady) {
                if (demo!!.isConnected) {
                    if (auth == AuthStatus.Authenticated.value) {
                        demo!!.Auth(pwd, AuthStatus.Protected_RW.value)
                    }
                    NdefFragment.setAnswer("Tag detected")
                    try {
                        demo!!.NDEF()
                    } catch (e: Exception) {
                        NdefFragment.setAnswer("Error: Tag lost, try again")
                        e.printStackTrace()
                    }

                } else {
                    if (NdefFragment.isWriteChosen()) {
                        NdefFragment.setAnswer("Tap tag to write NDEF content")
                    } else {
                        NdefFragment.setAnswer("Tap tag to read NDEF content")
                    }
                }
            }
        }
    }
}*/
