package com.nxp.nfc_demo.flutter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import io.flutter.plugin.common.PluginRegistry

abstract class AndroidFlutterMediator   {
    private val registrar: PluginRegistry.Registrar? = null
    private val internal_thread: FakeActivity? = null

    fun debug(msg:String, intent: Intent):Unit{
        Log.v(msg, "intent: $intent");
        Log.v(msg, "intent comp: ${intent.component}")
        Log.v(msg, "intent act: ${intent.action}")
        Log.v(msg, "intent cat: ${intent.categories}")
    }

    abstract fun intentMatched(intent: Intent): Boolean

    abstract fun resultMatched(requestCode: Int, data: Intent): Boolean

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent): Boolean {
        if(resultMatched(requestCode, data)){
            internal_thread?.onActivityResult(requestCode, resultCode, data)
            return true
        }
        return false
    }

    fun onCreate(savedInstanceState: Bundle?, intent: Intent, activity: Activity) {
        internal_thread?.onCreate(savedInstanceState, intent, activity)
    }

    fun onNewIntent(intent: Intent): Boolean{
        if(intentMatched(intent)){
            internal_thread?.onNewIntent(intent)
            return true
        }
        return false
    }
}